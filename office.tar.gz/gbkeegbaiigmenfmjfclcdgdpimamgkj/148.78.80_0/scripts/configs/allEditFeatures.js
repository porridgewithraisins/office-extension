(function(){var a={},b=window.localStorage.getItem("featureOverrides");b&&(a=JSON.parse(b));a.edit=!0;a.pointEdit=!0;window.localStorage.setItem("featureOverrides",JSON.stringify(a))})();
